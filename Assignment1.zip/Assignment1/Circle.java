/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

public class Circle {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the radius of the circle :");
        float pi=3.14f;
        int radius=sc.nextInt();
        double circum,area;
        circum=2*pi*radius;
        area=pi*radius*radius;
        System.out.println("Area of circle = "+area);
        System.out.println("Circumference of a circle = "+circum);       
        
    }
    
}