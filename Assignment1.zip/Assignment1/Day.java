/*
Write a program to read the days (eg. 670 days) as integer value using Scanner class.
Now convert the entered days into complete years, months and days and print them.
 */
package Assignment1;


import java.util.Scanner;

public class Day {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of days :");
        int n=sc.nextInt();
        int yr,month,days;
        
        yr=n/365;
        int rem_day;
        rem_day=n%365;
        
        month=rem_day/30;
        days=rem_day%30;
        System.out.println("Number of year :"+yr);
        System.out.println("Number of month :"+month);
        System.out.println("Number of day :"+days);
        
        
        
        
    }
}
