/*
Find the result of following expressions. You need to determine the primitive data type of the variable
by looking carefully the given expression and initialize variables by any random value.
A. y = x2 + 3x - 7 (print value of y) 
B. y = x++ + ++x (print value of x and y) 
C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]

 */
package Assignment1;

import static java.lang.Math.pow;

public class Expression {
    public static void main(String args[])
    {
        //A.
        int x=5,y;    //6 7
        y=(int)(pow(x,2)+(3*x)-7);
        System.out.println("y= "+y);
        
        //B.
        y= (x++) + (++x);
        // y= 5 +  7
        System.out.println("x="+x+" and y="+y);
        
        //C.
        x=3; //4 3 4
        y=2; //1
        int z = (x++) -(--y)- (--x) + (x++);
        // z= 3 - 1 - 3 + 3
        System.out.println("x="+x+" y="+y+" and z="+z);
        
        //D. z = x && y || !(x || y)
        boolean a=true, b=false, c;
        c= (a && b) || (!(a || b));
        System.out.println("c= "+c);
        
        
    }
}
