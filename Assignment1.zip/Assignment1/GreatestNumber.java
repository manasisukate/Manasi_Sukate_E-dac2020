/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

public class GreatestNumber {
    public static void main(String args[])
    {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter three numbers :");
            int a=sc.nextInt();
            int b=sc.nextInt();
            int c=sc.nextInt();
            if((a>b)&&(a>c))
            {
                System.out.println(a+" is a greater number.");
            }
            else if((b>a)&&(b>c))
            {
                 System.out.println(b+" is a greater number.");
            }
            else
            {
                System.out.println(c+" is a greater number.");
            }
    }
}
