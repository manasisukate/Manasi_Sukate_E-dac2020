/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

public class Marriage {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the age :");
        int age=sc.nextInt();
        System.out.println("Enter the male or female(m/f) :");
        char gen=sc.next().charAt(0);
        
        if(age>18 && gen=='f')
        {
            System.out.println("Valid Age");
        }
        else if(age>22 && gen=='m')
        {
            System.out.println("Valid Age");
        }
        else
        {
            System.out.println("Not Valid Age");
        }
    }
}
