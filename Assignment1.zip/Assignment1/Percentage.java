/*
Write a program to calculate sum of 5 subject’s marks & find percentage. Take the obtained marks from user using 
Scanner class. Output should be in this format [ percentage marks = 99 % ].
Use concatenation operator here.
 */
package Assignment1;

import java.util.Scanner;

public class Percentage {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 5 subject marks :");
        int a[]=new int[5];
        for(int i=0;i<5;i++)
        {
            a[i]=sc.nextInt();
        }
        float total;
        System.out.println("Enter total marks :");
        total=sc.nextFloat();
        int sum=0;
        for(int i=0;i<5;i++)
        {
            sum=sum+a[i];
        }
        System.out.println("Total marks ="+sum);
        float per=(float)((sum/total)*100);
        System.out.println("percentage ="+per+"%");
    }
}
