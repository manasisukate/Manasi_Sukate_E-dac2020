/*
Write a program to find the simple interest. Take the principle amount, rate of interest and time from user
using Scanner class.
 */
package Assignment1;

import java.util.Scanner;

public class SimpleInterest {
  public static void main(String args[])
  {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the principle amount :");
      int amt=sc.nextInt();
      System.out.println("Enter rate of interest :");
      int RoI=sc.nextInt();
      System.out.println("Enter the time in years :");
      int n=sc.nextInt();
      System.out.println("Simple Interest :"+(amt*RoI*n)/100);
  }
}
