/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment1;

import java.util.Scanner;

/**
 *
 * @author A
 */
public class Swapping {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int a,b,temp;
        System.out.println("Enter a :");
        a=sc.nextInt();
        System.out.println("Enter b :");
        b=sc.nextInt();
        temp=a;
        a=b;
        b=temp;
        System.out.println("a = "+a+", b = "+b);
                
    }
}
