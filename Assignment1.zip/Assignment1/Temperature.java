package Assignment1;

import java.util.Scanner;

public class Temperature {
    public static void main(String args[])
    {
       Scanner sc =new Scanner(System.in); 
       System.out.println("Enter the temperature in fahrenheit");
       double f=sc.nextDouble();
       double c=(5*(f-32))/9;
       System.out.println("Temperature in celcius :"+c);
    }
    
}
