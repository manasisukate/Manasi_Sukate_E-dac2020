/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.util.Scanner;


public class AveargeSumArray {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("How many values you want :");
        int n=sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the values :");
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        int sum=0;
        for(int i:arr){
            sum=sum+i;
        }
        int avg=sum/n;
        System.out.println("Sum ="+sum);
        System.out.println("Average ="+avg);
    }
}
