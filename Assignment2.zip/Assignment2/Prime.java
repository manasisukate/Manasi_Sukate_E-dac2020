/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.util.Scanner;

public class Prime {
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
       
       System.out.println("Enter the first number :");
       int fno=sc.nextInt();
       System.out.println("Enter the second number :");
       int sno=sc.nextInt();
       int count=0;
       if((fno>0)&&(sno>0)&&(sno>=fno))
       {
          for(int i=fno;i<=sno;i++) 
          {
              if((i%2)!=0)
              {
                  for(int n=2;n<(sno/2);n++)
                  {
                      if(i%n==0)
                      {                         
                          count++;
                      }
                      
                  }
                  if(count==0)
                  {
                      System.out.println(i);
                  }
              }
              
          }
       }
      
    }
    
}
