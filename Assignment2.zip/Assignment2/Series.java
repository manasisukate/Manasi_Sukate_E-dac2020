package Assignment2;

import java.util.*;

public class Series {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int x=12;
        System.out.println("Enter the number :");
        int n=sc.nextInt();
        System.out.print(x+"+");
        do
        {
            System.out.print(x+"+");
            x=x+10;
        }while(x<n);
    }   
}
