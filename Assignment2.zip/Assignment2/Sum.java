/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;

import java.util.Scanner;

public class Sum {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter array size :");
        int n=sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter array elements :");
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();            
        }
        int sumEven=0;
        int sumOdd=0;
        for(int i=0;i<n;i++)
        {
            if(arr[i]%2==0)  
            {
                sumEven=sumEven+arr[i];
            }
            else
            {
                sumOdd=sumOdd+arr[i];
            }
        }
        System.out.println("Sum of even elements :"+sumEven);
        System.out.println("Sum of odd elements :"+sumOdd);
    }
}
