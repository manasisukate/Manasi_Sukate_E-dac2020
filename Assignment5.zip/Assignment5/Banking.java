/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment5;

import java.util.Scanner;

class Bank
{
    private int accNo;
    private String accName;
    private String typeAcc;
    private final int amt;
    
    Bank()
    {
        amt=1000;
    }
    void set(int accNo,String accName,String typeAcc)
    {
        this.accNo=accNo;
        this.accName=accName;
        this.typeAcc=typeAcc;
    }
    
    void withdraw(int w_amt)
    {
        int total_amt = 0;
        if(w_amt<=amt)
        {
            total_amt=amt-w_amt;
        }
        else
        {
            System.out.println("Not sufficient balance!!!");
        }
        System.out.println("Account no :"+accNo+"\nAccount Name :"+accName+"\nType of account :"+typeAcc+"\nBalance :"+total_amt);
    }
    
    void deposite(int d_amt)
    {
        int total_amt;
        total_amt=amt+d_amt;
        System.out.println("Account no :"+accNo+"\nAccount Name :"+accName+"\nType of account :"+typeAcc+"\nBalance :"+total_amt);
    }
     
    
}
public class Banking {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your account number :");
        int no=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter your name :");
        String name=sc.nextLine();
        System.out.println("Enter your type of account :");
        String type=sc.nextLine();
        Bank b1=new Bank();
        b1.set(no,name,type);
        int ch;
        
        do
        {
        System.out.println("Enter your choice :");
        System.out.println("\n1.Withdraw\n2.Deposite\n3.Exit");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                System.out.println("How much amount you want to withdraw :");
                int w_amt=sc.nextInt();
                b1.withdraw(w_amt);
                break;
                
            case 2:
                System.out.println("How much amount you want to deposite :");
                int d_amt=sc.nextInt();
                b1.deposite(d_amt);
                break;
                
        }
        }while(ch!=3);
    }
}

