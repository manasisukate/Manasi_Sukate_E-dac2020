/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment5;

import java.util.Scanner;

class Book
{
   int bookId;
   String bookName;
   int price;
   

    Book(int id, String name, int pr) {
        bookId=id;
        bookName=name;
        price=pr;
    }

    void display() {
        System.out.println("Highest price book details are ");
        System.out.println("Book Id : "+bookId+"\nName : "+bookName+"\nPrice = "+price);
    }
    
    
}
public class BookInfo {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Book bk[]=new Book[5];
        for(int i=0;i<5;i++)
        {
            System.out.println("Enter "+(i+1)+" book details :");
            System.out.println("Enter book id :");
            int id=sc.nextInt();
            System.out.println("Enter name of book :");
            String name=sc.next();
            System.out.println("Enter the price of book :");
            int pr=sc.nextInt();
            bk[i]=new Book(id,name,pr);
        }
        
        int max=bk[0].price;
        for(int j=1;j<5;j++)
        {
            if(max<bk[j].price)
            {
                max=bk[j].price;
            }
        }
        
        for(int k=0;k<5;k++)
        {
            if(max==bk[k].price)
            {
                bk[k].display();
            }
        }
    }
}

