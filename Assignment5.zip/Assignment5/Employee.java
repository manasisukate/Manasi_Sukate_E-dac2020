/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment5;
class Employee {
    private int empId;
    private String empName;
    private static int total;
    
    void set(int empId,String empName,int total)
    {
        this.empId=empId;
        this.empName=empName;
        Employee.total=total; //Use static variable with class name. 
    }
    void display()
    {
        System.out.println("Id : "+empId+"\nName : "+empName+"\nTotal :"+total);
    }
}

class EmployeeTest
{
    public static void main(String args[])
    {
        Employee emp=new Employee();
        emp.set(11, "Manasi",1);
        emp.display(); 
        
        Employee emp1=new Employee();
        emp1.set(12, "Namrata",2);
        emp1.display();
    } 
}