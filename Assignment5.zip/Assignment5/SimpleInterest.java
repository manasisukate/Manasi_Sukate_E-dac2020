/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment5;

import java.util.*; 
class Simple{
double principleamount;
static double rIntrest;
int years;
double intrest;


double calculate(double p,double r,int years)
{
/*principleamount=p;
rIntrest=r;
years=years;*/
intrest=(p*r*years)/100;
return intrest;

}

}//end of Simple

class SimpleInterest{

public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter values for principle amount,rate of intrest,no of years");
double p=sc.nextDouble();
double x=sc.nextDouble();
int y=sc.nextInt();

Simple s=new Simple();
double z=s.calculate(p,x,y);

System.out.println("Simple intrest: "+z);

}
}