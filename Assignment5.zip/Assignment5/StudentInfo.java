/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment5;


import java.util.Scanner;

class Student
{
    private int rollNo;
    private String name;
    private int marks;
    
    Student(int rollNo,String name,int marks)
    {
       this.rollNo=rollNo;
       this.name=name;
       this.marks=marks;
    }
    
    void display()
    {
        System.out.println("Roll No : "+rollNo+"\nName : "+name+ "\nMarks : "+marks);
    }
}

public class StudentInfo {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter roll no :");
        int roll=sc.nextInt();
        System.out.println("Enter the name of student :");
        String name=sc.next();
        System.out.println("Enter the marks :");
        int marks=sc.nextInt();
        Student s1=new Student(roll,name,marks);   
        s1.display();
    }
    
}

